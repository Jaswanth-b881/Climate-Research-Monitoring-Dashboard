// Wait for HTML to load
document.addEventListener("DOMContentLoaded", function() {

    const API_KEY = 'b08bb2a9367ddb2a9b797feddfb0c302';

    // Update Chart.js Defaults for Dark Theme
    Chart.defaults.color = '#8f95a3';
    Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.05)';

    // Real-time System Clock
    setInterval(() => {
        document.getElementById('systemTime').innerText = new Date().toLocaleTimeString();
    }, 1000);

    // --- CHART INITIALIZATION ---
    
    // Diurnal Cycle Chart
    const ctx = document.getElementById('researchChart').getContext('2d');
    const researchChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['00:00', '03:00', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00'],
            datasets: [
                {
                    label: 'Temperature (°C)',
                    data: [22, 21, 20, 25, 29, 31, 28, 24],
                    borderColor: '#ff6b6b', backgroundColor: 'rgba(255, 107, 107, 0.2)',
                    yAxisID: 'y-temp', tension: 0.4, fill: true
                },
                {
                    label: 'Humidity (%)',
                    data: [80, 82, 85, 70, 55, 45, 60, 75],
                    borderColor: '#4facfe', backgroundColor: 'transparent',
                    yAxisID: 'y-humid', tension: 0.4, borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true, interaction: { mode: 'index', intersect: false },
            scales: {
                'y-temp': { type: 'linear', position: 'left', title: { display: true, text: 'Temperature (°C)' } },
                'y-humid': { type: 'linear', position: 'right', title: { display: true, text: 'Humidity (%)' }, grid: { drawOnChartArea: false } }
            }
        }
    });

    // Recent 12-Month Trend Chart 
    const recentCtx = document.getElementById('recentYearChart').getContext('2d');
    const recentYearChart = new Chart(recentCtx, {
        type: 'line',
        data: {
            labels: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr'],
            datasets: [{
                label: 'Deviation from Normal (°C)',
                data: [1.18, 1.25, 1.31, 1.40, 1.42, 1.38, 1.45, 1.48, 1.50, 1.52, 1.55, 1.58], 
                borderColor: '#ff6b6b', backgroundColor: 'rgba(255, 107, 107, 0.2)',
                borderWidth: 3, fill: true, tension: 0.4, pointRadius: 4, pointBackgroundColor: '#ff6b6b'
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { title: { display: true, text: 'Anomaly (°C)' } } } }
    });

    // Historical Shift Chart 
    const historicalYears = Array.from({length: 26}, (_, i) => 2000 + i);
    const historicalData = [
        0.40, 0.54, 0.63, 0.62, 0.53, 0.68, 0.64, 0.66, 0.54, 0.65, 
        0.72, 0.60, 0.65, 0.68, 0.74, 0.90, 1.01, 0.92, 0.85, 0.98, 
        1.02, 0.85, 0.89, 1.18, 1.35, 1.45
    ];
    const histCtx = document.getElementById('historicalChart').getContext('2d');
    const historicalChart = new Chart(histCtx, {
        type: 'bar',
        data: {
            labels: historicalYears,
            datasets: [{
                label: 'Annual Anomaly (°C)',
                data: historicalData,
                backgroundColor: historicalData.map(val => val > 1.0 ? '#ff6b6b' : '#4facfe'), 
                borderRadius: 4
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { x: { ticks: { maxTicksLimit: 6 } }, y: { title: { display: true, text: 'Anomaly (°C)' } } } }
    });

    // --- LIVE DATA FETCHING LOGIC ---
    window.fetchWeatherData = function(city) {
        const badge = document.getElementById('apiStatus');
        badge.className = 'badge bg-info text-dark me-3';
        badge.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching Live Data...';

        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`)
            .then(response => {
                if (!response.ok) throw new Error('City not found');
                return response.json();
            })
            .then(data => {
                document.getElementById('locationDisplay').innerHTML = `Target Location: <strong>${data.name}, ${data.sys.country}</strong> | Lat: ${data.coord.lat.toFixed(2)}, Lon: ${data.coord.lon.toFixed(2)}`;
                
                const temp = data.main.temp;
                document.getElementById('ui-temp').innerText = temp.toFixed(1) + '°C';
                document.getElementById('ui-feels').innerText = data.main.feels_like.toFixed(1) + '°C';
                document.getElementById('ui-humid').innerText = data.main.humidity + '%';
                
                const windKmh = (data.wind.speed * 3.6).toFixed(1);
                document.getElementById('ui-wind').innerText = windKmh + ' km/h';
                document.getElementById('ui-rain').innerText = data.clouds.all + '%';

                const sunriseTime = new Date(data.sys.sunrise * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                const sunsetTime = new Date(data.sys.sunset * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                document.getElementById('ui-sunrise').innerText = sunriseTime;
                document.getElementById('ui-sunset').innerText = sunsetTime;

                const tempShift = temp - 25; 
                const baseTempCurve = [22, 21, 20, 25, 29, 31, 28, 24];
                researchChart.data.datasets[0].data = baseTempCurve.map(val => parseFloat((val + tempShift).toFixed(1)));
                researchChart.update();

                badge.className = 'badge bg-success text-white me-3';
                badge.innerHTML = '<i class="fas fa-check-circle"></i> API: Connected & Live';

                setHistoricalComparison(temp);
            })
            .catch(error => {
                console.error(error);
                badge.className = 'badge bg-danger text-white me-3';
                badge.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error: City Not Found';
                setTimeout(() => {
                    badge.className = 'badge bg-success text-white me-3';
                    badge.innerHTML = '<i class="fas fa-check-circle"></i> API: Connected & Live';
                }, 3000);
            });
    }

    // --- ON THIS DAY LOGIC ---
    function setHistoricalComparison(currentTemp) {
        const today = new Date();
        const lastYear = new Date(today);
        lastYear.setFullYear(today.getFullYear() - 1);

        const options = { month: 'long', day: 'numeric', year: 'numeric' };
        document.getElementById('lastYearDate').innerText = lastYear.toLocaleDateString('en-US', options);

        const lastYearTemp = (currentTemp - 1.3).toFixed(1);
        document.getElementById('lastYearTemp').innerText = lastYearTemp + '°C';
    }

    // Fetch initial data for Amaravati on load
    fetchWeatherData('Amaravati');
});

// --- SEARCH FUNCTIONALITY (Attached to window so HTML form can access it) ---
window.searchCity = function(event) {
    event.preventDefault(); 
    const cityInput = document.getElementById('cityInput').value.trim();
    if (!cityInput) return; 
    
    window.fetchWeatherData(cityInput);
    document.getElementById('cityInput').value = ''; 
}