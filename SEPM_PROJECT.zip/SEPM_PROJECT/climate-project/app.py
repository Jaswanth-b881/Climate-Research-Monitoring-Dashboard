from flask import Flask, render_template

app = Flask(__name__)

# This route serves your index.html page
@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    # Runs the server on port 5000
    app.run(debug=True)